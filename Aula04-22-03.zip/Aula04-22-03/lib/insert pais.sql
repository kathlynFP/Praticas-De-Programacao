INSERT INTO `pais` (`id`,`nome`,`populacao`,`area`) VALUES (1 , 'Brasil'	, 205002000		, 8512000);
INSERT INTO `pais` (`id`,`nome`,`populacao`,`area`) VALUES (2 , 'China'		, 1372470000	, 9600000);
INSERT INTO `pais` (`id`,`nome`,`populacao`,`area`) VALUES (3 , 'Canada'	, 35851774		, 9975000);
INSERT INTO `pais` (`id`,`nome`,`populacao`,`area`) VALUES (4 , 'Russia'	, 146606730		, 17075000);
INSERT INTO `pais` (`id`,`nome`,`populacao`,`area`) VALUES (5, 'India'		, 1278160000	, 3287590);

